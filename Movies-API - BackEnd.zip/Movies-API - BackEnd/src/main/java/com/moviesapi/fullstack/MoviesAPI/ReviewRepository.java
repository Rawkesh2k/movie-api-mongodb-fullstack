package com.moviesapi.fullstack.MoviesAPI;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.io.ObjectInput;

public interface ReviewRepository extends MongoRepository<Review, ObjectId> {
}
