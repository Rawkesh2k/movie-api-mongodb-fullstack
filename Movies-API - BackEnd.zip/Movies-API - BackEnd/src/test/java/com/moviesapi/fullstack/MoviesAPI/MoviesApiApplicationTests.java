package com.moviesapi.fullstack.MoviesAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
